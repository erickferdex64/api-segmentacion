# CrossTooth (CVPR 2025) · worker para Runpod Serverless

Endpoint que recibe **un STL** (arcada completa) y devuelve **el PLY segmentado en alta resolución**,
con un color por cara (gris = encía, 16 colores = dientes), igual que `*_segmentado_HD.ply` del notebook.

Pipeline (el mismo que el notebook, sin las vistas de matplotlib):

```
STL ──► orientar (permutar ejes, quitar espejo, flip_z, flip_y)   ← "la vuelta"
    ──► decimación quadric a 15 999 caras                          ← "la decimada"
    ──► CrossTooth (PointTransformer, solo point features)         ← predict.py
    ──► KNN k=3 de las 16k caras a las caras originales            ← "la vuelta" al HD
    ──► PLY con colores por cara (base64 o subido a un bucket S3)
```

## Archivos

| archivo | qué es |
|---|---|
| `Dockerfile` | build en 2 etapas: compila `pointops` (CUDA) en la imagen *devel* y sirve desde la imagen *runtime* |
| `handler.py` | worker de Runpod: carga el modelo **una vez**, calienta con el caso de ejemplo y atiende peticiones |
| `crosstooth_pipeline.py` | geometría (orientación, decimación, KNN, escritura PLY). Sin torch, testeable en CPU |
| `patch_pointops.py` | el parche de `queryandgroup` que aplicaste en el notebook |
| `requirements.txt` | dependencias Python (torch viene de la imagen base, no lo añadas) |
| `test_input.json` | petición de prueba (usa el escaneo de ejemplo del repo) |
| `client_example.py` | cómo llamar al endpoint y guardar el PLY |

## Desplegar en Runpod

1. Sube esta carpeta a un repositorio de GitHub (el `Dockerfile` en la raíz).
2. Runpod → **Serverless → New Endpoint → Import Git Repository** → elige repo y rama. Runpod construye la imagen
   y la vuelve a construir con cada push. (Alternativa: `docker build -t tuusuario/crosstooth:1 . && docker push …`
   y crear el endpoint desde la imagen.)
3. Configuración del endpoint:
   - **GPU**: Ampere/Ada/Hopper (RTX 4090, L4, L40S, A5000, A100, H100…). La imagen base es CUDA 12.4:
     para RTX 5090/B200 cambia `PYTORCH_TAG` a una 12.8+ y añade `12.0` a `TORCH_CUDA_ARCH_LIST`.
   - **Container disk**: 20 GB.
   - **Max workers**: 1–3 · **Active (min) workers**: 0 (escala a cero) · **Idle timeout**: 5 s · **FlashBoot**: on.
   - **Execution timeout**: 300 s (una arcada de 300k caras tarda ~10 s en GPU).
   - Variables opcionales para no devolver el PLY en base64 sino por URL (S3/R2/Runpod S3-compatible):
     `BUCKET_ENDPOINT_URL`, `BUCKET_ACCESS_KEY_ID`, `BUCKET_SECRET_ACCESS_KEY`, `BUCKET_NAME`.
     `WARMUP=0` desactiva la inferencia de calentamiento al arrancar.
4. Prueba desde la pestaña **Requests** del endpoint con el contenido de `test_input.json`.

## Petición (`input`)

| campo | tipo | por defecto | descripción |
|---|---|---|---|
| `stl_base64` | string | – | STL en base64 (binario o ASCII). Puede ir **gzip** antes del base64 (se detecta solo) |
| `stl_url` | string | – | alternativa: URL del STL/PLY/OBJ; el worker lo descarga |
| `jaw` | `"upper"` / `"lower"` | – | solo afecta a los nombres de diente y numeración FDI de la respuesta |
| `flip_z` / `flip_y` | bool | auto | fuerza la orientación (como el `flip_z` manual del notebook) |
| `target_faces` | int | 15999 | objetivo de la decimación (máx. 16000) |
| `output_frame` | `"original"` / `"model"` | original | `original` = mismas coordenadas que tu STL; `model` = el sistema rotado que ve la red (como guardaba el notebook) |
| `ascii_ply` | bool | false | PLY ASCII en vez de binario (3× más grande) |
| `compress_output` | bool | false | gzip del PLY antes del base64 (≈ la mitad) |
| `return_decimated` | bool | false | devuelve también la malla de 16k segmentada (como `lower_seg.ply`) |
| `name` | string | scan | nombre base para el archivo de salida |

Límites de Runpod: **10 MB** por petición en `/run`, **20 MB** en `/runsync`. Un STL binario de 300k caras pesa
~15 MB (→ ~12 MB en gzip+base64), así que usa `/runsync` con gzip o, mejor, `stl_url`.

## Respuesta (`output`)

```json
{
  "ply_base64": "...", "ply_gzipped": false, "ply_binary": true, "ply_size_bytes": 6336414,
  "n_vertices": 144045, "n_faces": 287970, "n_faces_decimated": 15998, "n_faces_predicted": 15998,
  "output_frame": "original", "jaw": "upper",
  "labels": {
    "present": [0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14], "n_teeth": 13,
    "palette": {"0": [125,125,125], "1": [240,0,0], "...": "..."},
    "names":   {"0": "gum", "1": "UL1", "...": "...", "9": "UR1"},
    "fdi":     {"1": 21, "2": 22, "...": "...", "9": 11},
    "face_counts": {"0": 153743, "1": 10596, "...": "..."}
  },
  "orientation": {"axis_order_xyz_from": [0,1,2], "mirror_fixed": false,
                  "flip_z": false, "flip_z_method": "boundary", "flip_y": false, "flip_y_method": "arch_width",
                  "transform": [[1,0,0],[0,1,0],[0,0,1]]},
  "timings_ms": {"load": 900, "orient": 60, "decimate": 2700, "inference": 800, "knn": 300, "write": 60, "total": 5000},
  "warnings": []
}
```
Si hay bucket configurado, en vez de `ply_base64` llega `ply_url` (URL firmada, 7 días).
Si algo falla, `output` es `{"error": "..."}`.

Los colores del PLY son los de `label2color_lower` del repo (el checkpoint usa esa paleta para ambas arcadas);
`labels.palette` te da la tabla color → etiqueta para reconstruir las etiquetas como hacías con `np.unique`.

## Notas sobre la orientación (lo que cambia respecto al notebook)

- Permutación de ejes por extensión (largo→X, medio→Y, corto→Z) y corrección de espejo con `det`, igual que tu celda
  del *upper*. Se aplica también al *lower* (tu celda del lower no corregía el espejo).
- **Lado de las coronas (`flip_z`)**: tu heurística del "centro de la U" invierte el escaneo de ejemplo del propio repo
  (`YBSESUN6_upper`), que ya está en el sistema que espera la red. Aquí se usa el borde abierto del escaneo (está siempre
  en el lado de la encía/paladar, opuesto a las coronas); si la malla es cerrada, la normal media o la base plana.
  Con el escaneo de ejemplo da identidad (correcto). El método usado y sus números vienen en `orientation`.
- **Dirección de los incisivos (`flip_y`)**: se compara la anchura en X de los dos extremos de la U (el extremo
  cerrado es estrecho). Los incisivos quedan hacia −Y, como en el notebook.
- Si en algún caso falla, pásale `flip_z` / `flip_y` a mano; en `warnings` avisa si detecta menos de 5 dientes.

## Probar en local (en un Pod con GPU)

```bash
docker build -t crosstooth-worker .           # o el build lo hace Runpod desde GitHub
docker run --gpus all -it crosstooth-worker python /app/handler.py --test_input '{"input": {"stl_url": "https://raw.githubusercontent.com/XiShuFan/CrossTooth_CVPR2025/main/YBSESUN6_upper.obj", "jaw": "upper"}}'
```
Sin Docker, dentro del pod donde ya te funciona `predict.py`: copia `handler.py` y `crosstooth_pipeline.py` junto al
repo, `pip install -r requirements.txt`, `CROSSTOOTH_DIR=/ruta/CrossTooth_CVPR2025 python handler.py` (usa
`test_input.json`). Con `--rp_serve_api` levanta una API local en `http://localhost:8000/runsync`.
